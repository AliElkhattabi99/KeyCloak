export const environment = {
  production: false,
  configFile: 'assets/config/config.dev.json'
};
